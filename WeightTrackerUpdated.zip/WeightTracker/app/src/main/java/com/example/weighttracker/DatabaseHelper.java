package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import org.mindrot.jbcrypt.BCrypt;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String TAG = "DatabaseHelper";
    public static final String DATABASE_NAME = "WeightTracker.db";
    public static final int DATABASE_VERSION = 2;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COLUMN_USER_ID = "user_id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";

    // Weights table
    public static final String TABLE_WEIGHTS = "weights";
    public static final String COLUMN_WEIGHT_ID = "weight_id";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";
    public static final String COLUMN_GOAL = "goal";
    public static final String COLUMN_USER_FK = "user_id";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL("CREATE TABLE " + TABLE_USERS + "("
                    + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_USERNAME + " TEXT UNIQUE NOT NULL,"
                    + COLUMN_PASSWORD + " TEXT NOT NULL)");

            db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + "("
                    + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_DATE + " TEXT NOT NULL,"
                    + COLUMN_WEIGHT + " REAL NOT NULL,"
                    + COLUMN_GOAL + " REAL,"
                    + COLUMN_USER_FK + " INTEGER NOT NULL,"
                    + "FOREIGN KEY(" + COLUMN_USER_FK + ") REFERENCES "
                    + TABLE_USERS + "(" + COLUMN_USER_ID + "))");
        } catch (Exception e) {
            Log.e(TAG, "Error creating tables: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            if (oldVersion < 2) {
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
                db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
                onCreate(db);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error upgrading database: " + e.getMessage());
        }
    }

    public static boolean isPasswordValid(String password) {
        return password != null && password.matches("^(?=.*[0-9])(?=.*[!@#$%^&*]).{8,}$");
    }

    public boolean addUser(String username, String password) {
        if (!isPasswordValid(password)) {
            Log.e(TAG, "Password does not meet requirements");
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, BCrypt.hashpw(password, BCrypt.gensalt(12)));

        try {
            return db.insert(TABLE_USERS, null, values) != -1;
        } catch (Exception e) {
            Log.e(TAG, "Error adding user: " + e.getMessage());
            return false;
        }
    }

    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_PASSWORD};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        try (Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                String storedHash = cursor.getString(cursor.getColumnIndex(COLUMN_PASSWORD));
                return BCrypt.checkpw(password, storedHash);
            }
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Error validating user: " + e.getMessage());
            return false;
        }
    }

    public long getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USER_ID};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        try (Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(cursor.getColumnIndex(COLUMN_USER_ID));
            }
            return -1;
        }
    }

    public boolean addWeight(long userId, String date, double weight, Double goal) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_FK, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        if (goal != null) {
            values.put(COLUMN_GOAL, goal);
        }

        try {
            return db.insert(TABLE_WEIGHTS, null, values) != -1;
        } catch (Exception e) {
            Log.e(TAG, "Error adding weight: " + e.getMessage());
            return false;
        }
    }

    public Cursor getWeightsByUser(long userId) {
        return this.getReadableDatabase().query(
                TABLE_WEIGHTS,
                null,
                COLUMN_USER_FK + " = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                COLUMN_DATE + " DESC");
    }

    public boolean deleteWeight(long weightId) {
        SQLiteDatabase db = this.getWritableDatabase();
        String whereClause = COLUMN_WEIGHT_ID + " = ?";
        String[] whereArgs = {String.valueOf(weightId)};

        try {
            return db.delete(TABLE_WEIGHTS, whereClause, whereArgs) > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error deleting weight: " + e.getMessage());
            return false;
        }
    }

    // NEW METHOD TO FIX THE ERROR
    public boolean deleteUserAndWeights(long userId) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            db.beginTransaction();

            // First delete all weights for this user
            db.delete(TABLE_WEIGHTS, COLUMN_USER_FK + " = ?", new String[]{String.valueOf(userId)});

            // Then delete the user
            int deletedRows = db.delete(TABLE_USERS, COLUMN_USER_ID + " = ?", new String[]{String.valueOf(userId)});

            db.setTransactionSuccessful();
            return deletedRows > 0;
        } catch (Exception e) {
            Log.e(TAG, "Error deleting user and weights: " + e.getMessage());
            return false;
        } finally {
            db.endTransaction();
            db.close();
        }
    }
}
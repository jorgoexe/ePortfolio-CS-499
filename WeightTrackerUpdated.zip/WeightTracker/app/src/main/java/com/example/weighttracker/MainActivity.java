package com.example.weighttracker;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private WeightAdapter adapter;
    private DatabaseHelper dbHelper;
    private long userId;
    private String username;
    private TextView tvWelcome, tvProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent intent = getIntent();
        username = intent.getStringExtra("USERNAME");
        userId = intent.getLongExtra("USER_ID", -1);

        if (userId == -1) {
            showToast("Session expired. Please login again.");
            navigateToLogin();
            return;
        }

        initializeViews();
        setupDatabase();
        loadUserWeights();
    }

    private void initializeViews() {
        recyclerView = findViewById(R.id.recyclerView);
        tvWelcome = findViewById(R.id.tv_welcome);
        tvProgress = findViewById(R.id.tv_progress);
        FloatingActionButton fab = findViewById(R.id.fab);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        tvWelcome.setText("Welcome, " + username + "!");
        fab.setOnClickListener(v -> showWeightDialog());
    }

    private void setupDatabase() {
        dbHelper = new DatabaseHelper(this);
    }

    private void loadUserWeights() {
        Cursor cursor = dbHelper.getWeightsByUser(userId);
        adapter = new WeightAdapter(this, cursor);
        recyclerView.setAdapter(adapter);
        updateProgressSummary(cursor);
    }

    private void updateProgressSummary(Cursor cursor) {
        if (cursor != null && cursor.moveToFirst()) {
            double latestWeight = cursor.getDouble(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT));
            int goalColumn = cursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL);

            if (goalColumn != -1 && !cursor.isNull(goalColumn)) {
                double goal = cursor.getDouble(goalColumn);
                if (latestWeight <= goal) {
                    tvProgress.setText("Goal achieved! 🎉");
                } else {
                    double remaining = latestWeight - goal;
                    tvProgress.setText(String.format("%.1f lbs to goal", remaining));
                }
                tvProgress.setVisibility(View.VISIBLE);
            }
        }
    }

    private void showWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = getLayoutInflater().inflate(R.layout.dialog_weight, null);

        EditText etDate = view.findViewById(R.id.et_date);
        EditText etWeight = view.findViewById(R.id.et_weight);
        EditText etGoal = view.findViewById(R.id.et_goal);

        etDate.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date()));

        builder.setView(view)
                .setTitle("Add Weight Entry")
                .setPositiveButton("Save", (dialog, which) -> {
                    try {
                        String date = etDate.getText().toString();
                        double weight = Double.parseDouble(etWeight.getText().toString());
                        Double goal = etGoal.getText().toString().isEmpty() ?
                                null : Double.parseDouble(etGoal.getText().toString());

                        if (dbHelper.addWeight(userId, date, weight, goal)) {
                            refreshData();
                            showToast("Entry saved");
                        }
                    } catch (NumberFormatException e) {
                        showToast("Invalid numbers");
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void refreshData() {
        Cursor newCursor = dbHelper.getWeightsByUser(userId);
        adapter.swapCursor(newCursor);
        updateProgressSummary(newCursor);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.menu_logout) {
            navigateToLogin();
            return true;
        } else if (item.getItemId() == R.id.menu_delete_account) {
            confirmAccountDeletion();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void confirmAccountDeletion() {
        new AlertDialog.Builder(this)
                .setTitle("Delete Account")
                .setMessage("All data will be deleted permanently")
                .setPositiveButton("Delete", (d, w) -> deleteAccount())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void deleteAccount() {
        new Thread(() -> {
            boolean success = dbHelper.deleteUserAndWeights(userId);
            runOnUiThread(() -> {
                showToast(success ? "Account deleted" : "Deletion failed");
                if (success) navigateToLogin();
            });
        }).start();
    }

    private void navigateToLogin() {
        startActivity(new Intent(this, LoginActivity.class));
        finish();
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) dbHelper.close();
        if (adapter != null) adapter.swapCursor(null);
        super.onDestroy();
    }
}
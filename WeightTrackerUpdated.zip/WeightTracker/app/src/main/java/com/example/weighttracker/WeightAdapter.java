package com.example.weighttracker;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {
    private final Context context;
    private Cursor cursor;
    private final int dateColumnIndex;
    private final int weightColumnIndex;
    private final int goalColumnIndex;

    public WeightAdapter(Context context, Cursor cursor) {
        this.context = context;
        this.cursor = cursor;
        this.dateColumnIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DATE);
        this.weightColumnIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_WEIGHT);
        this.goalColumnIndex = cursor.getColumnIndex(DatabaseHelper.COLUMN_GOAL);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_weight, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (!cursor.moveToPosition(position)) return;

        holder.tvDate.setText(cursor.getString(dateColumnIndex));
        holder.tvWeight.setText(String.format("%.1f lbs", cursor.getDouble(weightColumnIndex)));

        if (goalColumnIndex != -1 && !cursor.isNull(goalColumnIndex)) {
            double goal = cursor.getDouble(goalColumnIndex);
            double currentWeight = cursor.getDouble(weightColumnIndex);

            holder.tvGoal.setText(String.format("%.1f lbs", goal));
            holder.tvGoalLabel.setVisibility(View.VISIBLE);
            holder.tvGoal.setVisibility(View.VISIBLE);
            holder.tvProgress.setVisibility(View.VISIBLE);

            if (currentWeight <= goal) {
                holder.tvProgress.setText("✓ Achieved");
                holder.tvProgress.setTextColor(ContextCompat.getColor(context, R.color.green_500));
            } else {
                holder.tvProgress.setText(String.format("%.1f lbs to go", currentWeight - goal));
                holder.tvProgress.setTextColor(ContextCompat.getColor(context, android.R.color.holo_red_light));
            }
        } else {
            holder.tvGoalLabel.setVisibility(View.GONE);
            holder.tvGoal.setVisibility(View.GONE);
            holder.tvProgress.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        return cursor != null ? cursor.getCount() : 0;
    }

    public void swapCursor(Cursor newCursor) {
        if (cursor != null) cursor.close();
        cursor = newCursor;
        if (newCursor != null) notifyDataSetChanged();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight, tvGoalLabel, tvGoal, tvProgress;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tv_date);
            tvWeight = itemView.findViewById(R.id.tv_weight);
            tvGoalLabel = itemView.findViewById(R.id.tv_goal_label);
            tvGoal = itemView.findViewById(R.id.tv_goal);
            tvProgress = itemView.findViewById(R.id.tv_progress);
        }
    }
}
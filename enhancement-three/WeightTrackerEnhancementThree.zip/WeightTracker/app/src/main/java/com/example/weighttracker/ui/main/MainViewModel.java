package com.example.weighttracker.ui.main;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.weighttracker.data.WeightRepository;
import com.example.weighttracker.model.WeightEntry;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainViewModel extends AndroidViewModel {

    private final WeightRepository repository;
    private final ExecutorService executorService = Executors.newSingleThreadExecutor();

    public MainViewModel(@NonNull Application application) {
        super(application);
        repository = new WeightRepository(application.getApplicationContext());
    }

    // --- Weight Management ---

    public LiveData<List<WeightEntry>> getWeightEntries(long userId) {
        return repository.getWeightsForUser(userId);
    }

    public LiveData<List<Double>> getMovingAverage() {
        return repository.getMovingAverage();
    }

    public void addWeight(long userId, String date, double weight, Double goal, Runnable callback) {
        executorService.execute(() -> {
            repository.insertWeight(new WeightEntry(userId, date, weight, goal));
            if (callback != null) callback.run();
        });
    }

    public void deleteWeight(long weightId, long userId, Runnable callback) {
        executorService.execute(() -> {
            repository.removeWeight(weightId, userId);
            if (callback != null) callback.run();
        });
    }

    public void deleteUser(long userId, Runnable callback) {
        executorService.execute(() -> {
            repository.deleteUserAndWeights(userId);
            if (callback != null) callback.run();
        });
    }

    // --- Logging Support ---

    public void logWeightAction(String action, WeightEntry entry) {
        String message = String.format(
                "Action: %s | Date: %s | Weight: %.2f%s",
                action,
                entry.getDate(),
                entry.getWeight(),
                entry.getGoal() != null ? " | Goal: " + entry.getGoal() : ""
        );
        Log.d("WeightLog", message);
    }

    // --- User Management ---

    public void addUser(String username, String password, UserCallback callback) {
        executorService.execute(() -> {
            boolean success = repository.addUser(username, password);
            if (callback != null) callback.onComplete(success);
        });
    }

    public void validateUser(String username, String password, UserCallback callback) {
        executorService.execute(() -> {
            boolean valid = repository.validateUser(username, password);
            if (callback != null) callback.onComplete(valid);
        });
    }

    public void getUserId(String username, UserIdCallback callback) {
        executorService.execute(() -> {
            long userId = repository.getUserId(username);
            if (callback != null) callback.onUserIdFetched(userId);
        });
    }

    // --- Callback Interfaces ---

    public interface UserCallback {
        void onComplete(boolean success);
    }

    public interface UserIdCallback {
        void onUserIdFetched(long userId);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        repository.close();
        executorService.shutdown();
    }
}

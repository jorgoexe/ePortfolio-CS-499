package com.example.weighttracker.model;

public class WeightEntry {
    private long id;          // unique ID for each entry
    private long userId;
    private String date;
    private double weight;
    private Double goal;      // optional

    // Constructor with id (for entries loaded from DB)
    public WeightEntry(long id, long userId, String date, double weight, Double goal) {
        this.id = id;
        this.userId = userId;
        this.date = date;
        this.weight = weight;
        this.goal = goal;
    }

    // Constructor without id (for new entries before DB insert)
    public WeightEntry(long userId, String date, double weight, Double goal) {
        this.userId = userId;
        this.date = date;
        this.weight = weight;
        this.goal = goal;
    }

    // Getters and setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return userId;
    }

    public String getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }

    public Double getGoal() {
        return goal;
    }
}

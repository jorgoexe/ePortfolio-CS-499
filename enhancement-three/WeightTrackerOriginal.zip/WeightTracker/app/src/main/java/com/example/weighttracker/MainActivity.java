package com.example.weighttracker;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private DatabaseHelper dbHelper;
    private WeightAdapter adapter;
    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> showWeightDialog());

        loadWeights();
    }

    private void loadWeights() {
        Cursor cursor = dbHelper.getAllWeights();
        adapter = new WeightAdapter(this, cursor);
        recyclerView.setAdapter(adapter);
    }

    private void showWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View view = LayoutInflater.from(this).inflate(R.layout.dialog_weight, null);

        EditText etDate = view.findViewById(R.id.et_date);
        EditText etWeight = view.findViewById(R.id.et_weight);
        EditText etGoal = view.findViewById(R.id.et_goal);

        builder.setView(view)
                .setTitle("Add Weight Entry")
                .setPositiveButton("Save", (dialog, which) -> {
                    String date = etDate.getText().toString();
                    double weight = Double.parseDouble(etWeight.getText().toString());
                    double goal = Double.parseDouble(etGoal.getText().toString());

                    if(dbHelper.addWeight(date, weight, goal)) {
                        loadWeights();
                        checkGoalAchieved(weight, goal);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void checkGoalAchieved(double currentWeight, double goal) {
        if(currentWeight <= goal) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                sendSMSAlert();
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        }
    }

    private void sendSMSAlert() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(
                    "5556", // Replace with actual number
                    null,
                    "Goal weight achieved! Congratulations!",
                    null,
                    null);
            Toast.makeText(this, "Alert sent!", Toast.LENGTH_SHORT).show();
        } catch (SecurityException e) {
            Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE &&
                grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            sendSMSAlert();
        }
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}

package com.example.weighttracker.ui.login;

import androidx.lifecycle.ViewModel;

public class LoginViewModel extends ViewModel {
    // TODO: Add login logic here later
}
